import java.util.Scanner;
import java.util.ArrayList;

/**
 * Multiplies number that are beyond capability of primitive data type integer
 *
 * @author  Patrik Trebichavsky
 * @version 1.0 7/8/21
 * 
 */


public class MyMultiplicationMethod {

	private String number1;
	private String number2;
	
	public MyMultiplicationMethod() {
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Insert first number");
		this.number1 = scanner.nextLine();
		ArrayList<Integer> number1InArray = CharArrayToIntArraylist(number1.toCharArray());

		System.out.println("Insert Second number");
		this.number2 = scanner.nextLine();
		ArrayList<Integer> number2InArray = CharArrayToIntArraylist(number2.toCharArray());

		System.out.println("Result is : "+Multiplication(number1InArray,number2InArray));
		
		}

	public static ArrayList<Integer> ReverseCharArrayList(ArrayList<Integer> beforeReverse){
		ArrayList<Integer> afterReverse = new ArrayList<Integer>();
		for (int i = 0; i<beforeReverse.size();i++) {
			afterReverse.add(beforeReverse.get(beforeReverse.size()-i-1));
	 }
		return afterReverse;
	}
//Converts CharArrayToIntArray	
	public static ArrayList<Integer> CharArrayToIntArraylist(char[] charArray){
		ArrayList<Integer> intArrayList = new ArrayList<Integer>();
		for (char a : charArray) {
			intArrayList.add(Character.getNumericValue(a));
		}
		return intArrayList;
	}
//Multiplies Each value in both ArrayLists and adds them to result array and converts it back to string 	
	public static String Multiplication(ArrayList<Integer> number1, ArrayList<Integer> number2) {
		
		ArrayList<Integer> resultArray =	new ArrayList<Integer>();
		String result = "";
		
		number1 = ReverseCharArrayList(number1);
		number2 = ReverseCharArrayList(number2);
		
		for (int i = 0; i<number2.size() ; i++) {
			
			int Multiplier = number2.get(i);
			int remainder = 0;
			int position = 0;
			
			for (int multipliedNumber : number1 ) {
				if (resultArray.size() < position+1+i) resultArray.add(null);
				if (resultArray.get(position+i) == null) {
					multipliedNumber = multipliedNumber*Multiplier + remainder;
					resultArray.set(position + i,multipliedNumber%10);
				}else if(resultArray.get(position+i) != null) {
					multipliedNumber = multipliedNumber*Multiplier + remainder +resultArray.get(position+i);
					resultArray.set(position + i,multipliedNumber%10 );
				}
				remainder = multipliedNumber/10;
				position ++;	
			}
	 }
		resultArray = ReverseCharArrayList(resultArray);
		for (int a : resultArray) {
			result = result+a;
		}
		 return result;
		
	}
	
	
}
