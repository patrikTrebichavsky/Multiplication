import java.math.BigInteger;
import java.util.Scanner;

public class BigIntegerMultiplication {

	public BigIntegerMultiplication() {
	
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter Multiplicand");
		BigInteger number1 = new BigInteger(scanner.nextLine());
		System.out.println("Enter Multiplier");
		BigInteger number2 = new BigInteger(scanner.nextLine());
		System.out.println("Result is : "+number2.multiply(number1));

	}
}
